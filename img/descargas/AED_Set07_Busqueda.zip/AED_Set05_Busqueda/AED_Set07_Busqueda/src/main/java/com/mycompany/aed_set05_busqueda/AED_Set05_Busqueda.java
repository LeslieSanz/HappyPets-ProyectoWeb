/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.aed_set05_busqueda;

import com.mycompany.aed_set05_busqueda.Clases.cBusqueda;
import java.util.Scanner;

/**
 *
 * @author lsilvau
 */
public class AED_Set05_Busqueda {

    public static void main(String[] args) {
        int n=20, valor;
        cBusqueda oBusq=new cBusqueda(n);
        oBusq.llenaArreglo();oBusq.burbuja_Intercambio();
        System.out.println(oBusq.toString());
        System.out.print("Ingrese un valor ");
        Scanner scan=new Scanner(System.in );
        valor = scan.nextInt();
        int indice=oBusq.busquedaBinaria(valor);
        if(indice >=0)
            System.out.println("VCalor encontrado en la posicion "+ indice);
        else System.out.println("Valor no encontrado");
    }
}
