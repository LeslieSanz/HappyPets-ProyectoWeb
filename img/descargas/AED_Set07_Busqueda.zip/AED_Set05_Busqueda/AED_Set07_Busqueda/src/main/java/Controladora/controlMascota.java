/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controladora;

import com.mycompany.aed_set05_busqueda.Clases.cMascota;

/**
 *
 * @author lsilvau
 */
public class controlMascota {
    private cMascota oMascotas[];
    private int indice;
    public controlMascota(int n){
        oMascotas= new cMascota[n];
        indice= -1;
    }
    public void insertaMascota(cMascota oMascota){
        int indMax=oMascotas.length-1;
        if(indice < indMax){
            indice++;
            oMascotas[indice]= oMascota;
        }
    }
    public String muestraMascotas(){
        String cadena="";
        for(int i=0; i<= indice;i++){
            cadena+=oMascotas[i].toString()+"\n";
        }
        return cadena;
    }
    public String buscaNombre(String nombre){
        int i=0;
        while(i <indice && !nombre.equals(oMascotas[i].getNombre()) )
            i++;
        //System.out.println(i+" "+oMascotas[i]);
        if(nombre.equals(oMascotas[i].getNombre()))
            return oMascotas[i].getNombre();
        else return "No encontrado";
    }
}
