/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aed_set05_busqueda.Clases;

import java.util.Arrays;

/**
 *
 * @author lsilvau
 */
public class cBusqueda {
    private int arreglo[];
    public cBusqueda(int n){
        arreglo = new int[n];
    }
    public void llenaArreglo(){
        int indMayor=arreglo.length-1;
        for (int i = 0; i <= indMayor; i++) {
            arreglo[i]=(int)(Math.random()*(50-5+1)+5);
        }
    }
    public String toString(){
        return Arrays.toString(arreglo);
    }
    public void burbuja_Intercambio(){
        int indMayor=arreglo.length-1; boolean ordenado=false;
        int temp;
        while(ordenado == false){
            ordenado= true;
            for (int i = 0; i < indMayor; i++) {
                if(arreglo[i]> arreglo[i+1]){
                    temp=arreglo[i]; arreglo[i]=arreglo[i+1];
                    arreglo[i+1]= temp; ordenado= false;
                }
            }
        }
    }
    public int busquedaBinaria(int valor){
        int indMenor=0, indMayor=arreglo.length-1;
        int indMedio=(indMayor+indMenor)/2;
        while(indMenor< indMayor && valor != arreglo[indMedio]){
            if (valor < arreglo[indMedio])
                indMayor = indMedio-1;
            else indMenor= indMedio+1;
            indMedio=(indMayor+indMenor)/2;
        }
        if(valor == arreglo[indMedio])
            return indMedio;
        else return -1;
    }
}
