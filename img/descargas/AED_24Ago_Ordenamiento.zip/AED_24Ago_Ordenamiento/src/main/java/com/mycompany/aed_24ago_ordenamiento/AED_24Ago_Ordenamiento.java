/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.aed_24ago_ordenamiento;

import Clases.cOrdenamiento;

/**
 *
 * @author lsilvau
 */
public class AED_24Ago_Ordenamiento {

    public static void main(String[] args) {
        int n=20;
        cOrdenamiento oOrdena= new cOrdenamiento(n);
        oOrdena.llenaAreglo();
        System.out.println(oOrdena.toString());
        oOrdena.ordSeleccion();
        System.out.println(oOrdena.toString());
    }
}
