/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases;

import java.util.Arrays;

/**
 *
 * @author lsilvau
 */
public class cOrdenamiento {
    private int arreglo[];

    public cOrdenamiento(int n) {
        arreglo=new int[n];
    }
    public void llenaAreglo(){
        int indMax= arreglo.length-1;
        for(int i=0;i<= indMax;i++){
            arreglo[i]=(int)(Math.random()*(47-5+1)+5);   // valores de5 al 47
        }
    }
    public int hallaMenor(int i,int indMax){
        int menor=arreglo[i];int indMenor=i;
        for(int j=i; j<= indMax;j++){
            if(arreglo[j]<menor)
            {
                menor= arreglo[j]; indMenor= j;
            }
        }
        return indMenor;  
    }
    public void ordSeleccion(){
        int indMax= arreglo.length-1;int indMenor,aux;
        for(int i=0;i<= indMax;i++){
            indMenor=hallaMenor(i, indMax);
            aux=arreglo[indMenor];
            arreglo[indMenor]= arreglo[i];
            arreglo[i] = aux;
        }
    }
    public String toString(){
        return Arrays.toString(arreglo);
    }    
}
