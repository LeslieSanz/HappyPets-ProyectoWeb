/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Clases;

/**
 *
 * @author lsilvau
 */
public class mainLE {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ListaEnlazadaSimple les=new ListaEnlazadaSimple();
        String nombre;
        nombre="Carlos";les.insertaNodoxInicio(nombre);
        nombre="Farid";les.insertaNodoxInicio(nombre);
//        nombre="Esther";les.insertaNodoxInicio(nombre);
//        nombre="Leslie";les.insertaNodoxInicio(nombre);
        System.out.println(les.recorreLE());
//        nombre="Marco";les.insertaNodoxFinal(nombre);
//        nombre="George";les.insertaNodoxFinal(nombre);
//        nombre="Leonardo";les.insertaNodoxFinal(nombre);
//        System.out.println(les.recorreLE());
////        les.eliminaNodoxInicio();System.out.println(les.recorreLE());
////        les.eliminaNodoxInicio();System.out.println(les.recorreLE());
////        les.eliminaNodoxInicio();System.out.println(les.recorreLE());
//          les.eliminaNodoxFinal();System.out.println(les.recorreLE());
//          les.eliminaNodoxFinal();System.out.println(les.recorreLE());
//          les.eliminaNodoxFinal();System.out.println(les.recorreLE());
//        int numero;
//        for (int i=1; i<=10;i++){
//            numero=(int)(Math.random()*(64-5+1)+5);
//            System.out.print(numero+" ");
//            if(numero %2 == 0){
//                les.insertaNodoxFinal(numero+"");;
//            }
//        }
//        nombre="Leonardo";les.insertarEntreNodos(nombre, "Farid");
//        System.out.println("");
//        System.out.println(les.recorreLE());   
//        nombre="Leonardo";les.eliminaEntreNodos(nombre);
//        System.out.println(les.recorreLE());   
          System.out.println(les.buscaValor("Farid"));  
    }
    
}
