/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.aed_set19;

/**
 *
 * @author lsilvau
 */
public class AED_set19 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
