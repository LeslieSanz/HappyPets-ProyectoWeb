/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases;

/**
 *
 * @author lsilvau
 */
public class ListaEnlazadaSimple {
    private Nodo inicio, nuevo,p,q;
    
    public void insertaNodoxInicio(String nombre){
        nuevo = new Nodo(nombre);
        if(inicio== null)
            inicio= nuevo;
        else {
            nuevo.setSgte(inicio);
            inicio= nuevo;
        }
    }
    public void insertaNodoxFinal(String nombre){
        nuevo = new Nodo(nombre);
        if(inicio== null)
            inicio= nuevo;
        else {
            p=inicio;
            while(p.getSgte()!= null)
                p = p.getSgte();
            p.setSgte(nuevo);
        }        
    }
    public void eliminaNodoxInicio(){
        if(inicio != null){
            inicio=inicio.getSgte();
        }
    }
    public void eliminaNodoxFinal(){
        if(inicio!= null){
            if(inicio.getSgte()== null)
                inicio= null;
            else{
                p=inicio; q=inicio;
                while(p.getSgte()!= null){
                    q = p;
                    p = p.getSgte();
                }
                q.setSgte(null);
            }
        }
    }
    public String recorreLE(){
        String cadena="";
        p=inicio;
        while(p!= null){
            cadena += p.getNombre()+"  ";
            p = p.getSgte();
        }
        return cadena;
    }
    public String busca(String nombre){
        String cadena="";
        p=inicio;
        while(p.getSgte()!= null && !p.getNombre().equals(nombre) ){
            p = p.getSgte();
        }
        if(p.getNombre().equals(nombre))
            return p.getNombre();
        else
            return null;
    }    
}
