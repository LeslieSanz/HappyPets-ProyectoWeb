/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases;

/**
 *
 * @author lsilvau
 */
public class Nodo {
    private String nombre;
    private Nodo sgte;

    public Nodo(String nombre) {
        this.nombre = nombre;
    }
    public Nodo() {
    }
    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public Nodo getSgte() {
        return sgte;
    }
    public void setSgte(Nodo sgte) {
        this.sgte = sgte;
    }
    
}
